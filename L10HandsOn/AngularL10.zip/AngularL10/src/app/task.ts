export class Task {
    id!: number;
    name!: string;
    time!: string;
    description!: string;
    items!: string
}
