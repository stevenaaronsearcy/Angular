import { Component, OnInit } from '@angular/core';
import { from, Observable } from 'rxjs';
import { TaskDataService } from '../services/task-service.service';
import { Task } from '../task';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {

  tasks: Task[];

  getTasks(): void {
    this.taskDataService.getTask().subscribe(t => (this.tasks) = t);
  }

  getTask(id: number): Observable<Task> {
    return this.http.get<Task>(this.url + "/" + id);
  }

  deleteTask(id: number): void {
    this.taskDataService.deleteTask(id).subscribe(t => this.getTasks);
  }

  constructor(private taskDataService : TaskDataService) { }

  ngOnInit(): {
    this.getTasks();
  }

}
